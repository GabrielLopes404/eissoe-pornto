import rateLimit from "express-rate-limit";

// Global rate limit (default)
export const globalRateLimit = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 100,
  message: "Too many requests from this IP, please try again later",
  standardHeaders: true,
  legacyHeaders: false,
});

// Authentication endpoints (stricter)
export const authRateLimit = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 5,
  message: "Too many authentication attempts, please try again later",
  skipSuccessfulRequests: true,
});

// API Key generation (very strict)
export const apiKeyRateLimit = rateLimit({
  windowMs: 60 * 60 * 1000,
  max: 3,
  message: "Too many API key generation requests, please try again later",
});

// File upload (moderate)
export const uploadRateLimit = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 20,
  message: "Too many file uploads, please try again later",
});

// Report generation (moderate)
export const reportRateLimit = rateLimit({
  windowMs: 5 * 60 * 1000,
  max: 10,
  message: "Too many report generation requests, please try again later",
});

// Email sending (strict)
export const emailRateLimit = rateLimit({
  windowMs: 60 * 60 * 1000,
  max: 10,
  message: "Too many email requests, please try again later",
});

// Bulk operations (strict)
export const bulkRateLimit = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 5,
  message: "Too many bulk operations, please try again later",
});

// OFX/Reconciliation (moderate)
export const reconciliationRateLimit = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 10,
  message: "Too many reconciliation requests, please try again later",
});
