# LUCREI - Sistema de Gestão Financeira SaaS

## Overview
LUCREI is a comprehensive SaaS financial management system designed for small and medium-sized businesses. It centralizes financial operations through robust management of organizations, clients, invoices, transactions, categories, cost centers, documents, and tags. The platform also offers OFX imports, diverse export options, and detailed financial reports. The project's vision is to provide a modern, responsive, and intuitive platform that enhances business efficiency and offers a standardized user experience.

## Recent Changes (November 2025)
- **Enhanced Authentication System**: Complete redesign of login and registration pages with professional UI/UX
- **PF/PJ Support**: Added support for both Pessoa Física (PF) and Pessoa Jurídica (PJ) registration with document validation (CPF/CNPJ)
- **Improved Data Model**: Added `personType` field to organizations and customers tables
- **Landing Page Navigation**: Fixed all footer links to properly navigate to Terms, Privacy, Security, and LGPD pages
- **Export Functionality**: All export features working correctly (Dashboard, Reports, Import History)
- **Settings Page Enhancements**: Added functional theme switcher (light/dark/system) and notification preferences
- **Blog Page**: Fixed title truncation issues with responsive text sizing
- **Security Enhancements**: Maintained CSRF protection, rate limiting, and secure password hashing
- **Deployment Configuration**: Configured autoscale deployment for production-ready deployment
- **Complete RBAC System (November 7, 2025)**: Implemented comprehensive 3-level role-based access control with Admin and Owner management pages
- **CMS Implementation**: Full Content Management System with pages, blocks, and branding configuration
- **Support Ticket System**: Complete support ticket management with assignment, resolution, and internal messaging
- **Subscription Management**: Full subscription plan CRUD operations with metrics (MRR, churn, revenue)
- **Critical Security Fixes**: Fixed 3 severe tenant isolation vulnerabilities in user listing, ticket listing, and ticket mutations

## 🔐 Sistema de Acesso Administrativo

### Níveis de Permissão

O sistema possui 3 níveis de acesso baseados em funções (RBAC):

1. **OWNER (Proprietário)**
   - Primeiro usuário criado ao registrar uma organização
   - Controle total sobre a organização
   - Pode gerenciar todos os usuários, incluindo promover/rebaixar permissões
   - Único que pode deletar a organização ou transferir ownership
   
2. **ADMIN (Administrador)**
   - Permissões administrativas amplas
   - Pode gerenciar usuários, transações, relatórios
   - Pode convidar novos usuários e remover usuários existentes
   - Não pode alterar configurações críticas da organização
   
3. **CUSTOMER (Cliente/Usuário)**
   - Permissões limitadas
   - Pode gerenciar apenas suas próprias transações
   - Visualização de relatórios pessoais
   - Não tem acesso a funções administrativas

### Como Acessar como Administrador

1. **Primeiro Acesso (OWNER)**
   - Ao criar uma conta nova via `/register`, você automaticamente se torna OWNER da sua organização
   - Faça login em `/login` com suas credenciais
   - Você terá acesso completo a todas as funcionalidades

2. **Promover Usuário para ADMIN**
   - Como OWNER, acesse a seção de gerenciamento de usuários
   - Use o endpoint `POST /api/users/:id/promote` para promover um usuário a ADMIN
   - O usuário promovido terá permissões administrativas imediatas

3. **Rebaixar Permissões**
   - Como OWNER, use `POST /api/users/:id/demote` para rebaixar um ADMIN para CUSTOMER

### Segurança e Boas Práticas

- Senhas são hasheadas com bcrypt (12 rounds)
- Sessions são armazenadas no PostgreSQL
- CSRF protection ativo em todas as rotas
- Rate limiting para prevenir ataques
- **Tenant Isolation**: Todas as queries ADMIN são filtradas por `organizationId` usando `and()` para garantir isolamento de dados
- **Organization Verification**: Todos os endpoints de mutação verificam alinhamento de organização antes de modificar dados
- **Audit Logging**: Todas as ações administrativas são registradas na tabela `auditLogs`

### Endpoints RBAC Implementados

**Admin Routes (`/api/admin/*`)** - ADMIN e OWNER:
- `GET /users` - Listar usuários (paginado, com busca, isolamento por organização)
- `GET /users/:id` - Detalhes do usuário
- `POST /users/:id/promote` - Promover usuário a ADMIN (OWNER only)
- `POST /users/:id/demote` - Rebaixar usuário a CUSTOMER (OWNER only)
- `DELETE /users/:id` - Deletar usuário
- `GET /tickets` - Listar tickets de suporte (filtrado por organização e status)
- `GET /tickets/:id` - Detalhes do ticket com mensagens
- `POST /tickets/:id/assign` - Atribuir ticket (com verificação de organização)
- `POST /tickets/:id/resolve` - Resolver ticket (com verificação de organização)
- `POST /tickets/:id/reply` - Responder ticket (com verificação de organização)
- `GET /statistics` - Estatísticas da plataforma

**Owner Routes (`/api/owner/*`)** - OWNER only:
- `GET /plans` - Listar planos de assinatura
- `GET /plans/:id` - Detalhes do plano
- `POST /plans` - Criar plano
- `PUT /plans/:id` - Atualizar plano
- `DELETE /plans/:id` - Deletar plano
- `GET /branding` - Obter configuração de branding
- `PUT /branding` - Atualizar branding
- `GET /audit-logs` - Logs de auditoria (com filtros)
- `GET /audit-logs/:id` - Detalhes do log
- `GET /metrics` - Métricas (MRR, churn, revenue, LTV)
- `GET /payments` - Histórico de pagamentos
- `GET /subscriptions` - Gerenciar assinaturas

**CMS Routes (`/api/cms/*`)**:
- `GET /pages` - Listar páginas (público)
- `GET /pages/slug/:slug` - Obter página por slug (público)
- `GET /pages/:id` - Obter página por ID (público)
- `POST /pages` - Criar página (ADMIN/OWNER)
- `PUT /pages/:id` - Atualizar página (ADMIN/OWNER)
- `DELETE /pages/:id` - Deletar página (ADMIN/OWNER)
- `GET /pages/:pageId/blocks` - Listar blocos
- `POST /pages/:pageId/blocks` - Criar bloco (ADMIN/OWNER)
- `PUT /blocks/:id` - Atualizar bloco (ADMIN/OWNER)
- `DELETE /blocks/:id` - Deletar bloco (ADMIN/OWNER)
- `POST /pages/:pageId/blocks/reorder` - Reordenar blocos (ADMIN/OWNER)

### Frontend Pages Implementadas

**Admin Pages:**
- `/app/admin/users` - Gerenciamento de usuários com busca, paginação, promoção/rebaixamento e exclusão

**Owner Pages:**
- `/app/owner/plans` - Gerenciamento de planos de assinatura com CRUD completo

Para mais detalhes sobre permissões específicas, consulte `docs/rbac-matrix.md`

## User Preferences
- I prefer simple language and clear explanations.
- I want iterative development with frequent updates and feedback loops.
- Ask before making major changes to the core architecture or existing functionalities.
- Ensure all new features align with the established design system and visual patterns.
- Prioritize security and data integrity in all implementations.
- Do not make changes to the file `design_guidelines.md`.

## System Architecture
LUCREI employs a client-server architecture, utilizing **React 18** (Vite) for the frontend and **Express.js** (Node.js 20) for the backend, with **TypeScript** implemented across the full stack for type safety.

### UI/UX Decisions
The system features a modern, responsive, and user-friendly design.
- **Consistent Design System:** Adherence to a modern visual standard using `shadcn/ui` components.
- **Theming:** Supports dark/light themes via `next-themes`.
- **Animations:** Smooth transitions and micro-interactions powered by `Framer Motion`.
- **Visuals:** Incorporates gradients in titles, colored cards with shadows, gradient-backed Lucide React icons, and colored badges.
- **Data Visualization:** Interactive charts and graphs are rendered using `Recharts`.
- **Mobile Responsiveness:** Includes fluid typography, touch-optimized effects, horizontal table scrolling, and responsive image handling.

### Technical Implementations
- **Backend:**
    - **Database:** PostgreSQL managed with `Drizzle ORM`. Session storage uses PostgreSQL via `connect-pg-simple`.
    - **API:** RESTful API for CRUD operations across all entities (Organizations, Users, Customers, Invoices, Transactions, Categories, Cost Centers, Tags, Documents, Bank Accounts, Reconciliations, User Preferences, Subscriptions). Includes endpoints for metrics, activity logs, financial reports (DRE, Cash Flow, Statement), and data exports.
    - **Authentication:** Session-based via `Passport.js` and `express-session`, with `bcryptjs` (12 rounds) for password hashing. Features password reset, email verification, and session regeneration for security.
    - **Authorization:** Role-based access control (OWNER, ADMIN, CUSTOMER) and organization-level data isolation.
    - **Validation:** Server-side data validation enforced with `Zod` schemas.
    - **Security:** `Helmet` for HTTP headers, CORS, `express-rate-limit`, and global CSRF protection.
    - **Exports:** XLSX and CSV generation using `xlsx` and `json2csv`.
    - **CSV Import:** Comprehensive CSV parsing, validation, and bulk transaction creation.
    - **File Uploads:** `Multer` handles secure file uploads with MIME validation and size limits.
    - **Bank Account Management:** Automatic balance recalculation upon transaction modifications.
    - **Monitoring & Logging:** `Sentry` for error tracking and `Winston` for structured logging.
    - **Email Service:** `Resend` integration for HTML email notifications.
    - **OFX Parser:** Financial file parsing and matching.
    - **PDF Export:** Generation of DRE, Cash Flow, Statement, and Invoice PDFs using `PDFKit`.
    - **Caching:** Memoization with TTL.
- **Frontend:**
    - **State Management & Data Fetching:** `TanStack Query (React Query)` for data operations.
    - **Routing:** Light-weight client-side routing with `Wouter`.
    - **Form Management:** `React Hook Form` integrated with `Zod` for client-side validation.
    - **Error Handling:** Root and route-level error boundaries.
    - **Loading States:** Uses spinners, skeletons, and progress indicators.
    - **Accessibility:** Ensured through Radix UI components.
    - **Code Splitting:** Implemented with lazy loading.

### Feature Specifications
- **Core Modules:** Management of Customers, Invoices, Transactions, Categories, Cost Centers, Tags, Documents, Bank Accounts, Reconciliations, User Preferences, and Subscriptions.
- **Dashboard:** Provides key metrics, interactive charts, and recent activities.
- **Financial Transactions:** Comprehensive management with categorization, bank linking, cost center allocation, tags, and document attachments.
- **Reporting:** Real-time financial reports including DRE, Cash Flow, and Statement.
- **Data Operations:** Supports Excel, CSV, and JSON exports; OFX reconciliation.
- **Settings:** User profiles, preferences (theme, language, notifications), and organization management.

### System Design Choices
- **Modularity:** Structured project separating client, server, and shared code.
- **Scalability:** Designed with future growth in mind.
- **Observability:** Focus on logging and monitoring for production with Sentry and Winston.
- **Deployment:** Configured for automated, autoscale deployment.

## External Dependencies
- **Stripe:** For payment processing and subscription management.
- **Resend:** Email service for notifications and transactional emails.
- **PostgreSQL:** Primary relational database.
- **connect-pg-simple:** PostgreSQL session store.
- **Passport.js:** Authentication middleware.
- **bcryptjs:** Password hashing library.
- **Zod:** Schema validation library.
- **xlsx:** Excel file generation.
- **json2csv:** CSV file generation and parsing.
- **csv-parse:** CSV parsing for imports.
- **PDFKit:** PDF generation library.
- **Multer:** Middleware for handling `multipart/form-data`.
- **Recharts:** Charting library for React.
- **Lucide React:** Icon library.
- **Framer Motion:** Animation library.
- **TanStack Query (React Query):** Data fetching and state management.
- **shadcn/ui:** UI component library.
- **Tailwind CSS:** Utility-first CSS framework.
- **Vite:** Frontend build tool.
- **Sentry:** Error tracking and performance monitoring (optional).
- **Winston:** Logging library.