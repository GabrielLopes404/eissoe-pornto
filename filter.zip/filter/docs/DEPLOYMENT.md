# 🚀 LUCREI - Deployment Guide

## Table of Contents
- [Prerequisites](#prerequisites)
- [Environment Setup](#environment-setup)
- [Local Development](#local-development)
- [Docker Deployment](#docker-deployment)
- [Production Deployment](#production-deployment)
- [Database Migrations](#database-migrations)
- [Monitoring](#monitoring)
- [Troubleshooting](#troubleshooting)

---

## Prerequisites

### Required Accounts
- [ ] PostgreSQL database (Neon.tech recommended)
- [ ] Stripe account (for payments)
- [ ] Resend account (for emails)
- [ ] Domain name with DNS access
- [ ] Sentry account (optional, for error tracking)

### Required Tools
- Node.js 20+ 
- npm 10+
- Docker & Docker Compose (for containerized deployment)
- Git

---

## Environment Setup

### 1. Clone and Install

```bash
git clone https://github.com/yourusername/lucrei.git
cd lucrei
npm install
```

### 2. Configure Environment Variables

```bash
# Copy the example file
cp .env.example .env

# Edit .env with your values
nano .env
```

### 3. Generate Secrets

```bash
# Generate a secure SESSION_SECRET (64+ characters)
openssl rand -base64 64

# Add to .env:
SESSION_SECRET=<paste_generated_secret_here>
```

### 4. Configure External Services

#### PostgreSQL (Neon.tech)
1. Go to https://neon.tech
2. Create new project
3. Copy connection string
4. Add to `.env`:
   ```
   DATABASE_URL=postgresql://user:pass@host/db?sslmode=require
   ```

#### Stripe
1. Go to https://dashboard.stripe.com
2. Switch to **LIVE MODE** (production only)
3. Create 3 Products:
   - Personal: $29/month, $290/year
   - Business: $99/month, $990/year
   - Enterprise: $299/month, $2990/year
4. Create 2 Prices for each product (monthly + yearly)
5. Copy all 6 Price IDs to `.env`
6. Go to Developers > API Keys
7. Copy Secret Key to `.env` as `STRIPE_SECRET_KEY`
8. Go to Developers > Webhooks
9. Add endpoint: `https://yourdomain.com/api/stripe/webhook`
10. Select events:
    - `checkout.session.completed`
    - `customer.subscription.updated`
    - `customer.subscription.deleted`
11. Copy Webhook Secret to `.env` as `STRIPE_WEBHOOK_SECRET`

#### Resend (Email)
1. Go to https://resend.com
2. Create API Key → copy to `.env` as `RESEND_API_KEY`
3. Add Domain (e.g., lucrei.app)
4. Add DNS records from Resend to your DNS provider:
   - SPF (TXT)
   - DKIM (TXT)
   - DMARC (TXT - optional but recommended)
5. Wait for verification (10min - 48h)
6. Set `EMAIL_FROM=noreply@yourdomain.com`

---

## Local Development

### Start Development Server

```bash
# Apply database schema
npm run db:push

# Start development server
npm run dev
```

Server will be available at http://localhost:5000

### With Docker Compose (Development)

```bash
# Start PostgreSQL + PgAdmin
docker-compose -f docker-compose.dev.yml up -d

# Update DATABASE_URL in .env:
DATABASE_URL=postgresql://lucrei:lucrei_dev_password@localhost:5432/lucrei_dev

# Apply schema
npm run db:push

# Start app
npm run dev
```

Access PgAdmin at http://localhost:5050
- Email: admin@lucrei.local
- Password: admin

---

## Docker Deployment

### Build and Run with Docker

```bash
# Build the image
docker build -t lucrei:latest .

# Run the container
docker run -d \
  --name lucrei \
  -p 5000:5000 \
  --env-file .env.production \
  lucrei:latest
```

### Using Docker Compose (Production)

```bash
# Create production environment file
cp .env.example .env.production
# Edit .env.production with production values

# Start all services
docker-compose up -d

# View logs
docker-compose logs -f web

# Stop services
docker-compose down
```

### Update Deployment

```bash
# Pull latest code
git pull origin main

# Rebuild and restart
docker-compose up -d --build

# Clean up old images
docker image prune -f
```

---

## Production Deployment

### Replit Deploy

1. **Configure Secrets**
   - Go to Tools > Secrets
   - Add all environment variables from `.env.example`

2. **Configure Deployment**
   - Deployment is already configured in `.replit` file
   - Type: Autoscale
   - Build: `npm run build`
   - Run: `npm start`

3. **Deploy**
   - Click "Deploy" button in Replit
   - Or use CLI: `replit deploy`

4. **Custom Domain**
   - Go to Deployments > Custom Domain
   - Add your domain
   - Update DNS records
   - SSL certificate is automatic

### Manual Server Deployment

```bash
# On your server
git clone https://github.com/yourusername/lucrei.git
cd lucrei

# Install dependencies
npm ci --only=production

# Build application
npm run build

# Apply migrations
npm run db:push

# Start with PM2 (process manager)
npm install -g pm2
pm2 start npm --name "lucrei" -- start
pm2 save
pm2 startup
```

### Nginx Reverse Proxy

```nginx
# /etc/nginx/sites-available/lucrei

upstream lucrei {
    server localhost:5000;
}

server {
    listen 80;
    server_name lucrei.app www.lucrei.app;
    
    # Redirect to HTTPS
    return 301 https://$server_name$request_uri;
}

server {
    listen 443 ssl http2;
    server_name lucrei.app www.lucrei.app;

    # SSL certificates (from Let's Encrypt)
    ssl_certificate /etc/letsencrypt/live/lucrei.app/fullchain.pem;
    ssl_certificate_key /etc/letsencrypt/live/lucrei.app/privkey.pem;

    # Security headers
    add_header Strict-Transport-Security "max-age=31536000; includeSubDomains" always;
    add_header X-Frame-Options "SAMEORIGIN" always;
    add_header X-Content-Type-Options "nosniff" always;

    # Proxy settings
    location / {
        proxy_pass http://lucrei;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
        proxy_cache_bypass $http_upgrade;
    }

    # Health check
    location /api/health {
        proxy_pass http://lucrei;
        access_log off;
    }
}
```

Enable site:
```bash
sudo ln -s /etc/nginx/sites-available/lucrei /etc/nginx/sites-enabled/
sudo nginx -t
sudo systemctl reload nginx
```

---

## Database Migrations

### Apply Schema Changes

```bash
# Generate migration
npm run drizzle-kit generate:pg

# Review generated SQL in migrations/ folder

# Apply migration
npm run drizzle-kit migrate

# Or use push for simple changes
npm run db:push
```

### Backup Database

```bash
# Manual backup
pg_dump $DATABASE_URL > backup_$(date +%Y%m%d).sql

# Restore backup
psql $DATABASE_URL < backup_20241104.sql
```

### Automated Backups (Neon)

1. Go to Neon Dashboard > Project > Backups
2. Enable automated backups
3. Set schedule: Daily at 3 AM UTC
4. Retention: 30 days
5. Test restore procedure

---

## Monitoring

### Health Checks

```bash
# Health endpoint
curl https://lucrei.app/api/health

# Liveness probe
curl https://lucrei.app/api/liveness

# Readiness probe
curl https://lucrei.app/api/readiness

# Metrics (Prometheus format)
curl https://lucrei.app/metrics
```

### Setup Uptime Monitoring

1. **UptimeRobot** (Free)
   - Go to https://uptimerobot.com
   - Add monitor:
     - Type: HTTPS
     - URL: https://lucrei.app
     - Interval: 5 minutes
   - Add alert contacts (email, SMS)

2. **Better Stack** (Paid but better)
   - Go to https://betterstack.com
   - Add monitor with custom checks
   - Integrate with Slack/Discord

### Setup Error Tracking (Sentry)

```bash
# Install Sentry
npm install @sentry/node @sentry/react
```

Add to `.env`:
```
SENTRY_DSN=https://xxx@o123456.ingest.sentry.io/123456
```

Sentry is already integrated in the code.

---

## Troubleshooting

### Application Won't Start

```bash
# Check logs
docker-compose logs -f web

# Check environment variables
printenv | grep -E '(DATABASE|STRIPE|RESEND|SESSION)'

# Verify database connection
psql $DATABASE_URL -c "SELECT 1"

# Check port availability
lsof -i :5000
```

### Database Connection Issues

```bash
# Test connection
psql $DATABASE_URL

# Check SSL mode
# For Neon, always use ?sslmode=require

# Verify credentials
echo $DATABASE_URL
```

### Email Not Sending

```bash
# Check Resend status
curl https://api.resend.com/domains \
  -H "Authorization: Bearer $RESEND_API_KEY"

# Verify domain
# DNS records must be fully propagated

# Check logs
grep -i "resend" logs/combined.log
```

### Stripe Webhooks Failing

```bash
# Check webhook secret
echo $STRIPE_WEBHOOK_SECRET

# Test webhook locally with Stripe CLI
stripe listen --forward-to localhost:5000/api/stripe/webhook

# Trigger test event
stripe trigger checkout.session.completed

# Check webhook logs in Stripe Dashboard
```

### High Memory Usage

```bash
# Check memory
docker stats lucrei

# Restart application
docker-compose restart web

# Or with PM2
pm2 restart lucrei
```

### Slow Performance

```bash
# Check database indexes
psql $DATABASE_URL -c "\di"

# Analyze slow queries
# Enable slow query log in PostgreSQL

# Check metrics
curl https://lucrei.app/metrics | grep http_request_duration

# Monitor resources
htop
```

---

## Security Checklist

- [ ] All secrets in environment variables (never in code)
- [ ] SESSION_SECRET is strong and unique (64+ characters)
- [ ] Stripe in LIVE mode (production)
- [ ] HTTPS enabled with valid SSL certificate
- [ ] CORS configured with production domains only
- [ ] Database uses SSL connection
- [ ] Regular backups configured and tested
- [ ] Error tracking (Sentry) configured
- [ ] Uptime monitoring configured
- [ ] Rate limiting enabled
- [ ] Security headers configured (Helmet)
- [ ] Dependencies updated (`npm audit fix`)

---

## Deployment Checklist

### Pre-Deployment
- [ ] All environment variables configured
- [ ] Database schema applied
- [ ] Stripe products and prices created
- [ ] Resend domain verified
- [ ] DNS records configured
- [ ] SSL certificate ready
- [ ] Backup strategy in place

### Deployment
- [ ] Build succeeds (`npm run build`)
- [ ] Type check passes (`npm run check`)
- [ ] Tests pass (when implemented)
- [ ] Health check returns 200
- [ ] Application starts successfully

### Post-Deployment
- [ ] Health endpoint accessible
- [ ] Test user registration
- [ ] Test email verification
- [ ] Test password reset
- [ ] Test Stripe checkout (test mode first)
- [ ] Verify webhooks working
- [ ] Check error tracking (Sentry)
- [ ] Monitor uptime (first 24h)
- [ ] Verify backups running

---

## Support

For deployment issues:
1. Check this documentation
2. Review logs (`docker-compose logs -f`)
3. Check health endpoints
4. Review error tracking (Sentry)
5. Contact support

---

**Last Updated:** November 4, 2025  
**Version:** 1.0.0
