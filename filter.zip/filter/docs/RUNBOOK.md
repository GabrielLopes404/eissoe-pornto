# 🚨 LUCREI - Operations Runbook

## Table of Contents
- [System Overview](#system-overview)
- [Emergency Contacts](#emergency-contacts)
- [Common Incidents](#common-incidents)
- [Monitoring & Alerts](#monitoring--alerts)
- [Recovery Procedures](#recovery-procedures)
- [Maintenance](#maintenance)

---

## System Overview

### Architecture
```
User → Nginx/Load Balancer → Node.js App → PostgreSQL
                                ↓
                        Stripe/Resend APIs
```

### Critical Services
- **Web Application**: Node.js Express (Port 5000)
- **Database**: PostgreSQL (Neon/self-hosted)
- **Email**: Resend API
- **Payments**: Stripe API

### Service Dependencies
```
App Health = Database UP AND Email Service UP AND Stripe API UP
```

---

## Emergency Contacts

### On-Call Rotation
| Role | Primary | Backup |
|------|---------|--------|
| Dev Lead | [Name] +1-xxx-xxx-xxxx | [Name] +1-xxx-xxx-xxxx |
| DevOps | [Name] +1-xxx-xxx-xxxx | [Name] +1-xxx-xxx-xxxx |
| DBA | [Name] +1-xxx-xxx-xxxx | [Name] +1-xxx-xxx-xxxx |

### Escalation Path
1. **Level 1** (0-15min): On-call engineer investigates
2. **Level 2** (15-30min): Escalate to Dev Lead
3. **Level 3** (30min+): Escalate to CTO

### External Contacts
- **Neon Support**: support@neon.tech
- **Stripe Support**: https://support.stripe.com
- **Resend Support**: support@resend.com

---

## Common Incidents

### 1. Application Down (HTTP 503)

**Symptoms:**
- Health check returning 503
- Users cannot access the site
- Uptime Robot alerts firing

**Diagnostic Steps:**
```bash
# 1. Check if app is running
docker ps | grep lucrei
# or
pm2 list

# 2. Check application logs
docker logs lucrei-web --tail 100
# or
pm2 logs lucrei --lines 100

# 3. Check health endpoint
curl https://lucrei.app/api/health

# 4. Check system resources
docker stats
# or
htop
```

**Common Causes & Fixes:**

**A. Out of Memory (OOM)**
```bash
# Check memory usage
docker stats lucrei-web

# If OOM killed:
docker-compose restart web

# Permanent fix: Increase memory limit in docker-compose.yml
services:
  web:
    mem_limit: 2g  # Increase from 1g to 2g
```

**B. Database Connection Pool Exhausted**
```bash
# Check active connections
psql $DATABASE_URL -c "SELECT count(*) FROM pg_stat_activity;"

# Restart app to reset pool
docker-compose restart web

# Review slow queries
psql $DATABASE_URL -c "
  SELECT pid, now() - pg_stat_activity.query_start AS duration, query
  FROM pg_stat_activity
  WHERE (now() - pg_stat_activity.query_start) > interval '5 seconds'
  ORDER BY duration DESC;
"
```

**C. Process Crashed**
```bash
# Check logs for crash
docker logs lucrei-web --tail 200 | grep -i "error\|crash\|fatal"

# Restart
docker-compose restart web

# If crash loops, check code errors
npm run check
```

**Recovery Time Objective (RTO):** < 5 minutes

---

### 2. Database Down

**Symptoms:**
- Health check shows database: down
- Application errors: "Cannot connect to database"
- All API requests failing

**Diagnostic Steps:**
```bash
# 1. Test database connection
psql $DATABASE_URL -c "SELECT 1"

# 2. Check database status (if self-hosted)
docker logs lucrei-db --tail 100

# 3. Check Neon status (if using Neon)
# Visit: https://status.neon.tech
```

**Common Causes & Fixes:**

**A. Database Container Down** (self-hosted)
```bash
# Check if running
docker ps | grep postgres

# Restart
docker-compose restart db

# If data corruption
docker-compose down
docker volume rm lucrei_postgres_data
# Then restore from backup (see Recovery Procedures)
```

**B. Neon Service Issue**
```bash
# Check status page
curl https://status.neon.tech/api/v2/status.json

# If outage:
# 1. Wait for Neon to resolve
# 2. Enable maintenance mode
# 3. Communicate with users
```

**C. Connection Limit Reached**
```bash
# Check active connections
psql $DATABASE_URL -c "
  SELECT count(*) as connections, usename
  FROM pg_stat_activity
  GROUP BY usename;
"

# Kill idle connections
psql $DATABASE_URL -c "
  SELECT pg_terminate_backend(pid)
  FROM pg_stat_activity
  WHERE state = 'idle'
  AND state_change < current_timestamp - INTERVAL '15 minutes';
"
```

**Recovery Time Objective (RTO):** < 15 minutes

---

### 3. Payment Processing Failure

**Symptoms:**
- Users report "Payment failed" errors
- Stripe webhooks failing
- Checkout sessions not completing

**Diagnostic Steps:**
```bash
# 1. Check Stripe status
curl https://status.stripe.com/api/v2/status.json

# 2. Check webhook logs
docker logs lucrei-web | grep -i "stripe"

# 3. Verify webhook secret
echo $STRIPE_WEBHOOK_SECRET

# 4. Check Stripe Dashboard > Webhooks
# Look for failed webhook deliveries
```

**Common Causes & Fixes:**

**A. Webhook Signature Mismatch**
```bash
# Regenerate webhook secret in Stripe Dashboard
# Update environment variable
# Restart application
docker-compose restart web
```

**B. Stripe API Down**
```bash
# Check Stripe status
# Visit: https://status.stripe.com

# If outage:
# 1. Enable maintenance mode for checkout
# 2. Queue failed webhooks for retry (if implemented)
# 3. Communicate with users
```

**C. Invalid Price IDs**
```bash
# Verify price IDs in environment
echo $STRIPE_PRICE_PERSONAL_MONTHLY

# Check in Stripe Dashboard > Products
# Ensure all 6 price IDs are correct
```

**Recovery Time Objective (RTO):** < 30 minutes

---

### 4. Email Not Sending

**Symptoms:**
- Users not receiving password reset emails
- Email verification not working
- Invoice notifications not sent

**Diagnostic Steps:**
```bash
# 1. Check Resend status
curl https://status.resend.com/api/v2/status.json

# 2. Check application logs
docker logs lucrei-web | grep -i "resend\|email"

# 3. Verify API key
echo $RESEND_API_KEY

# 4. Check domain verification
curl https://api.resend.com/domains \
  -H "Authorization: Bearer $RESEND_API_KEY"
```

**Common Causes & Fixes:**

**A. Domain Not Verified**
```bash
# Check DNS records
dig TXT lucrei.app | grep -i "resend\|spf\|dkim"

# If records missing:
# 1. Add DNS records from Resend dashboard
# 2. Wait for propagation (up to 48h)
# 3. Verify in Resend dashboard
```

**B. API Key Expired/Invalid**
```bash
# Generate new API key in Resend dashboard
# Update environment variable
docker-compose restart web
```

**C. Rate Limit Exceeded**
```bash
# Check Resend dashboard for limits
# Upgrade plan if necessary
# Implement queue for email sending
```

**Recovery Time Objective (RTO):** < 1 hour (DNS) or < 15 minutes (API key)

---

### 5. High CPU/Memory Usage

**Symptoms:**
- Slow response times
- Timeouts
- Server becomes unresponsive

**Diagnostic Steps:**
```bash
# 1. Check resource usage
docker stats lucrei-web

# 2. Check top processes
docker exec lucrei-web top

# 3. Check metrics endpoint
curl https://lucrei.app/metrics | grep process_cpu_usage

# 4. Check for memory leaks
docker logs lucrei-web | grep -i "heap\|memory"
```

**Common Causes & Fixes:**

**A. Memory Leak**
```bash
# Restart application (temporary fix)
docker-compose restart web

# Monitor memory growth
watch -n 5 'docker stats lucrei-web --no-stream'

# If leak confirmed:
# 1. Check code for event listeners not cleaned up
# 2. Review caching strategy
# 3. Deploy fix
```

**B. Infinite Loop / CPU Spike**
```bash
# Check what's using CPU
docker exec lucrei-web top -bn1

# Restart application
docker-compose restart web

# Review recent code changes
git log --oneline -10

# Rollback if necessary
```

**C. Database Query Performance**
```bash
# Check slow queries
psql $DATABASE_URL -c "
  SELECT query, calls, total_time, mean_time
  FROM pg_stat_statements
  ORDER BY mean_time DESC
  LIMIT 10;
"

# Add missing indexes if needed
# Optimize queries
```

**Recovery Time Objective (RTO):** < 10 minutes

---

## Monitoring & Alerts

### Health Checks

| Endpoint | Purpose | Expected Response | Check Interval |
|----------|---------|-------------------|----------------|
| `/api/health` | Overall health | 200 + status: healthy | 30s |
| `/api/liveness` | Process alive | 200 + status: alive | 10s |
| `/api/readiness` | Ready for traffic | 200 + status: ready | 30s |
| `/metrics` | Prometheus metrics | 200 + metrics | 60s |

### Critical Alerts

**1. Application Down**
- **Trigger**: Health check fails for 2 consecutive attempts (1 min)
- **Action**: Page on-call engineer immediately
- **SLA**: Respond within 5 minutes

**2. High Error Rate**
- **Trigger**: 5xx errors > 5% over 5 minutes
- **Action**: Alert on-call engineer
- **SLA**: Investigate within 15 minutes

**3. Database Connection Failure**
- **Trigger**: Database health check fails for 3 consecutive attempts
- **Action**: Page on-call engineer + DBA
- **SLA**: Respond within 10 minutes

**4. High Latency**
- **Trigger**: P95 response time > 2s for 5 minutes
- **Action**: Alert on-call engineer
- **SLA**: Investigate within 30 minutes

**5. Disk Space**
- **Trigger**: Disk usage > 85%
- **Action**: Alert DevOps
- **SLA**: Clean up within 2 hours

---

## Recovery Procedures

### Database Restore

**From Neon Backup:**
```bash
# 1. Go to Neon Dashboard > Backups
# 2. Select backup point
# 3. Click "Restore"
# 4. Choose new branch or replace
# 5. Update DATABASE_URL in environment
# 6. Restart application
```

**From Manual Backup:**
```bash
# 1. List available backups
ls -lh backups/

# 2. Restore from backup
psql $DATABASE_URL < backups/backup_20241104.sql

# 3. Verify data
psql $DATABASE_URL -c "SELECT count(*) FROM users;"

# 4. Restart application
docker-compose restart web
```

**Recovery Point Objective (RPO):** Last backup (24 hours max)

### Application Rollback

```bash
# 1. Check recent deployments
git log --oneline -10

# 2. Identify last working commit
LAST_GOOD_COMMIT=abc123

# 3. Rollback
git checkout $LAST_GOOD_COMMIT

# 4. Rebuild and deploy
docker-compose up -d --build

# 5. Verify health
curl https://lucrei.app/api/health

# 6. Monitor for 30 minutes
```

### Disaster Recovery (Complete Failure)

**Scenario: Entire system down, no immediate fix available**

**Steps:**
1. **Enable Maintenance Mode** (if available)
   ```nginx
   # Nginx config
   return 503 "System under maintenance. Back soon.";
   ```

2. **Communicate with Users**
   - Post on status page
   - Send email notification
   - Update social media

3. **Assess Damage**
   - Check all services
   - Identify root cause
   - Estimate recovery time

4. **Restore from Backups**
   - Database: Latest backup
   - Application: Last known good commit
   - Configuration: Stored in Git

5. **Test in Staging**
   - Verify all functionality
   - Run smoke tests

6. **Deploy to Production**
   - Update DNS if necessary
   - Restart all services
   - Monitor closely

7. **Post-Mortem**
   - Document incident
   - Identify preventive measures
   - Update runbook

**Total RTO:** < 4 hours

---

## Maintenance

### Scheduled Maintenance Windows

**Weekly:**
- Sunday 3:00 AM - 4:00 AM UTC
- Automated backups
- Database maintenance (VACUUM, ANALYZE)
- Log rotation

**Monthly:**
- First Sunday 2:00 AM - 4:00 AM UTC
- Security updates
- Dependency updates
- Performance optimization

### Pre-Maintenance Checklist
- [ ] Announce maintenance window (24h advance)
- [ ] Create backup
- [ ] Test changes in staging
- [ ] Prepare rollback plan
- [ ] Have on-call engineer ready

### Post-Maintenance Checklist
- [ ] Verify health checks
- [ ] Run smoke tests
- [ ] Monitor for 1 hour
- [ ] Document changes
- [ ] Communicate completion

---

## Quick Reference

### Useful Commands

```bash
# Restart application
docker-compose restart web

# View logs (last 100 lines)
docker-compose logs -f --tail 100 web

# Check application health
curl https://lucrei.app/api/health | jq

# Connect to database
psql $DATABASE_URL

# Check disk space
df -h

# Check memory usage
free -h

# List running processes
docker ps

# Execute command in container
docker exec -it lucrei-web sh

# Backup database now
pg_dump $DATABASE_URL > backup_$(date +%Y%m%d_%H%M%S).sql
```

### Important URLs

- **Production**: https://lucrei.app
- **Health**: https://lucrei.app/api/health
- **Metrics**: https://lucrei.app/metrics
- **Stripe Dashboard**: https://dashboard.stripe.com
- **Resend Dashboard**: https://resend.com
- **Neon Dashboard**: https://console.neon.tech
- **Sentry**: https://sentry.io

---

## Incident Log

### Template
```
Date: YYYY-MM-DD HH:MM UTC
Severity: Critical/High/Medium/Low
Duration: XX minutes
Affected Users: XXX
Root Cause: 
Resolution: 
Prevention: 
Lessons Learned: 
```

### Recent Incidents
(To be filled when incidents occur)

---

**Last Updated:** November 4, 2025  
**Next Review:** Monthly  
**Maintained By:** DevOps Team
