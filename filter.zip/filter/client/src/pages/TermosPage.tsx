import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { ArrowLeft, FileText } from "lucide-react";
import { motion } from "framer-motion";

export default function TermosPage() {
  const [, setLocation] = useLocation();

  const sections = [
    {
      title: "1. Aceitação dos Termos",
      content: "Ao acessar e usar o LUCREI, você concorda com estes Termos de Serviço. Se você não concorda, não use nossos serviços."
    },
    {
      title: "2. Descrição do Serviço",
      content: "O LUCREI é uma plataforma de gestão financeira baseada em nuvem que oferece ferramentas para controle de fluxo de caixa, emissão de faturas, relatórios e automação financeira."
    },
    {
      title: "3. Contas de Usuário",
      content: "Você é responsável por manter a confidencialidade de sua conta e senha. Você concorda em nos notificar imediatamente sobre qualquer uso não autorizado."
    },
    {
      title: "4. Uso Aceitável",
      content: "Você concorda em usar o serviço apenas para fins legais e de acordo com estes termos. É proibido usar o serviço para atividades ilegais ou fraudulentas."
    },
    {
      title: "5. Pagamentos e Assinaturas",
      content: "Os planos pagos são cobrados antecipadamente e renovados automaticamente. Você pode cancelar a qualquer momento, mas reembolsos são fornecidos apenas conforme descrito em nossa política."
    },
    {
      title: "6. Propriedade Intelectual",
      content: "Todo o conteúdo, recursos e funcionalidades do LUCREI são de propriedade da empresa e protegidos por leis de propriedade intelectual."
    },
    {
      title: "7. Limitação de Responsabilidade",
      content: "O LUCREI é fornecido 'como está'. Não garantimos que o serviço será ininterrupto ou livre de erros. Nossa responsabilidade é limitada ao valor pago pelo serviço."
    },
    {
      title: "8. Modificações",
      content: "Reservamos o direito de modificar estes termos a qualquer momento. Continuidade do uso após mudanças constitui aceitação dos novos termos."
    }
  ];

  return (
    <div className="dark min-h-screen bg-background text-foreground">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-4 md:px-8 py-12">
        <Button 
          variant="ghost" 
          onClick={() => setLocation("/")} 
          className="mb-8"
        >
          <ArrowLeft className="mr-2 h-4 w-4" />
          Voltar
        </Button>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="text-center mb-12"
        >
          <div className="flex justify-center mb-4">
            <div className="h-16 w-16 rounded-full bg-gradient-to-r from-primary to-primary/80 flex items-center justify-center">
              <FileText className="h-8 w-8 text-white" />
            </div>
          </div>
          <h1 className="text-2xl md:text-4xl sm:text-xl md:text-3xl md:text-5xl font-bold mb-4 bg-gradient-to-r from-primary to-primary/80 bg-clip-text text-transparent">
            Termos de Serviço
          </h1>
          <p className="text-muted-foreground">
            Última atualização: 4 de novembro de 2024
          </p>
        </motion.div>

        <Card className="mb-8">
          <CardContent className="p-4 md:p-8">
            <p className="text-muted-foreground mb-6">
              Estes Termos de Serviço regem seu uso da plataforma LUCREI. Por favor, leia atentamente.
            </p>

            <div className="space-y-6">
              {sections.map((section, index) => (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.5, delay: index * 0.1 }}
                >
                  <h2 className="text-xl font-bold mb-2">{section.title}</h2>
                  <p className="text-muted-foreground">{section.content}</p>
                </motion.div>
              ))}
            </div>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-r from-primary/10 to-primary/10 border-primary/20">
          <CardContent className="p-6 text-center">
            <h3 className="font-semibold mb-2">Dúvidas sobre os termos?</h3>
            <p className="text-sm text-muted-foreground mb-4">
              Nossa equipe jurídica está disponível para esclarecer qualquer questão
            </p>
            <Button 
              variant="outline"
              onClick={() => setLocation("/contato")}
            >
              Entre em Contato
            </Button>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
