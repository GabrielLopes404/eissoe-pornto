import { useState } from "react";
import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { X, PlayCircle, FileText, Lightbulb, MessageCircle, HelpCircle } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";

export default function HelpButton() {
  const [isOpen, setIsOpen] = useState(false);

  const menuItems = [
    { icon: PlayCircle, label: "Videoaulas para iniciantes", color: "bg-primary", href: "/help/videoaulas" },
    { icon: FileText, label: "Guias de ajuda", color: "bg-primary", href: "/help/guias" },
    { icon: Lightbulb, label: "Dicas", color: "bg-primary", href: "/help/dicas" },
    { icon: MessageCircle, label: "Dê seu feedback", color: "bg-primary", href: "/help/feedback" },
    { icon: HelpCircle, label: "Outros canais de ajuda", color: "bg-primary", href: "/help/suporte" },
  ];

  return (
    <div className="fixed bottom-6 right-6 z-50">
      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ opacity: 0, scale: 0.8, y: 20 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.8, y: 20 }}
            className="absolute bottom-20 right-0 w-64 bg-gradient-to-b from-primary to-primary rounded-lg shadow-2xl overflow-hidden"
          >
            {menuItems.map((item, index) => {
              const Icon = item.icon;
              return (
                <Link key={index} href={item.href}>
                  <motion.button
                    initial={{ opacity: 0, x: 20 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: index * 0.05 }}
                    onClick={() => setIsOpen(false)}
                    className="w-full flex items-center gap-3 px-5 py-4 text-white hover:bg-white/10 transition-colors border-b border-white/10 last:border-0"
                  >
                    <Icon className="h-5 w-5 flex-shrink-0" />
                    <span className="text-sm font-medium">{item.label}</span>
                  </motion.button>
                </Link>
              );
            })}
          </motion.div>
        )}
      </AnimatePresence>

      <Button
        onClick={() => setIsOpen(!isOpen)}
        className="h-16 w-16 rounded-full bg-gradient-to-br from-primary to-primary hover:from-primary hover:to-purple-700 shadow-lg hover:shadow-xl transition-all duration-300"
        size="icon"
      >
        <AnimatePresence mode="wait">
          {isOpen ? (
            <motion.div
              key="close"
              initial={{ rotate: -90, opacity: 0 }}
              animate={{ rotate: 0, opacity: 1 }}
              exit={{ rotate: 90, opacity: 0 }}
              transition={{ duration: 0.2 }}
            >
              <X className="h-7 w-7 text-white" />
            </motion.div>
          ) : (
            <motion.div
              key="help"
              initial={{ rotate: 90, opacity: 0 }}
              animate={{ rotate: 0, opacity: 1 }}
              exit={{ rotate: -90, opacity: 0 }}
              transition={{ duration: 0.2 }}
              className="text-3xl font-bold text-white"
            >
              ?
            </motion.div>
          )}
        </AnimatePresence>
      </Button>
    </div>
  );
}
