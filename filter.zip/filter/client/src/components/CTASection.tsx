import { Button } from "@/components/ui/button";
import { ArrowRight, Sparkles, Check, Zap, TrendingUp, Shield } from "lucide-react";
import { motion, useScroll, useTransform } from "framer-motion";
import { useLocation } from "wouter";
import { useRef } from "react";

export default function CTASection() {
  const [, setLocation] = useLocation();
  const containerRef = useRef<HTMLDivElement>(null);
  
  const { scrollYProgress } = useScroll({
    target: containerRef,
    offset: ["start end", "end start"]
  });

  const y = useTransform(scrollYProgress, [0, 1], ["100px", "-100px"]);
  const opacity = useTransform(scrollYProgress, [0, 0.5, 1], [0.5, 1, 0.5]);
  
  return (
    <section ref={containerRef} className="relative py-32 px-4 sm:px-6 lg:px-4 md:px-8 overflow-hidden">
      {/* Enhanced vibrant gradient background */}
      <div className="absolute inset-0 bg-gradient-to-br from-primary via-primary/ via-purple-600 to-primary/80" />
      
      {/* Animated gradient mesh overlay */}
      <motion.div 
        className="absolute inset-0"
        animate={{
          backgroundPosition: ['0% 0%', '100% 100%', '0% 0%'],
        }}
        transition={{
          duration: 20,
          repeat: Infinity,
          ease: "linear"
        }}
        style={{
          backgroundImage: 'none;
}
