import { useState, useEffect } from "react";
import { useLocation } from "wouter";
import { useTranslation } from "react-i18next";
import { Button } from "@/components/ui/button";
import {
  LayoutDashboard,
  Users,
  FileText,
  Settings,
  LogOut,
  Menu,
  X,
  Sparkles,
  Moon,
  Sun,
  Receipt,
  BarChart3,
  Import,
  HelpCircle,
  ChevronDown,
  Bell,
  Check,
} from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { useTheme } from "next-themes";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
  DropdownMenuSeparator,
} from "@/components/ui/dropdown-menu";
import HelpButton from "@/components/HelpButton";
import { differenceInDays } from "date-fns";

interface AppLayoutProps {
  children: React.ReactNode;
}

interface NavItem {
  name: string;
  href: string;
  icon: React.ComponentType<{ className?: string }>;
}

const getNavigation = (t: any): NavItem[] => [
  { name: t('nav.dashboard'), href: "/app/dashboard", icon: LayoutDashboard },
  { name: t('nav.transactions'), href: "/app/transactions", icon: Receipt },
  { name: t('nav.customers'), href: "/app/customers", icon: Users },
  { name: t('nav.reports'), href: "/app/reports", icon: BarChart3 },
  { name: t('nav.imports'), href: "/app/imports", icon: Import },
  { name: t('nav.reconciliations'), href: "/app/reconciliations", icon: FileText },
];

export default function AppLayout({ children }: AppLayoutProps) {
  const [location, setLocation] = useLocation();
  const { t } = useTranslation();
  const { toast } = useToast();
  const { theme, setTheme } = useTheme();
  const queryClient = useQueryClient();
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [user, setUser] = useState<any>(null);
  const [daysLeft, setDaysLeft] = useState(7);
  const [notifications, setNotifications] = useState<any[]>([]);
  const [unreadCount, setUnreadCount] = useState(0);
  const [csrfToken, setCsrfToken] = useState("");
  const navigation = getNavigation(t);

  useEffect(() => {
    fetch("/api/csrf-token", { credentials: "include" })
      .then((res) => res.json())
      .then((data) => setCsrfToken(data.csrfToken))
      .catch((error) => console.error("Failed to fetch CSRF token:", error));
  }, []);

  useEffect(() => {
    const fetchUser = async () => {
      try {
        const response = await fetch("/api/auth/me", {
          credentials: "include",
        });

        if (response.ok) {
          const data = await response.json();
          setUser(data.user);
          
          // Calculate days left in trial
          const userCreatedAt = new Date(data.user.createdAt || Date.now());
          const trialEndDate = new Date(userCreatedAt);
          trialEndDate.setDate(trialEndDate.getDate() + 7);
          const days = differenceInDays(trialEndDate, new Date());
          setDaysLeft(Math.max(0, days));
        } else {
          setLocation("/login");
        }
      } catch (error) {
        console.error("Failed to fetch user:", error);
        setLocation("/login");
      }
    };

    fetchUser();
  }, [setLocation]);

  useEffect(() => {
    const fetchNotifications = async () => {
      try {
        const response = await fetch("/api/notifications?limit=5", {
          credentials: "include",
        });

        if (response.ok) {
          const data = await response.json();
          setNotifications(data.notifications || []);
          setUnreadCount(data.unreadCount || 0);
        }
      } catch (error) {
        console.error("Failed to fetch notifications:", error);
      }
    };

    if (user) {
      fetchNotifications();
      const interval = setInterval(fetchNotifications, 30000);
      return () => clearInterval(interval);
    }
  }, [user]);

  const savePreferencesMutation = useMutation({
    mutationFn: async (preferences: any) => {
      let token = csrfToken;
      
      if (!token) {
        const csrfResponse = await fetch('/api/csrf-token', { credentials: 'include' });
        const data = await csrfResponse.json();
        token = data.csrfToken;
        setCsrfToken(token);
      }
      
      const res = await fetch("/api/user/preferences", {
        method: "PUT",
        headers: { "Content-Type": "application/json", "x-csrf-token": token },
        body: JSON.stringify(preferences),
        credentials: "include",
      });
      if (!res.ok) throw new Error("Failed to save preferences");
      return res.json();
    },
    onSuccess: (data, variables) => {
      queryClient.invalidateQueries({ queryKey: ["/api/user/preferences"] });
    },
    onError: (error, variables) => {
      if (variables.themePreference) {
        const previousTheme = theme === 'dark' ? 'system' : theme === 'light' ? 'dark' : 'light';
        setTheme(previousTheme);
      }
      toast({ title: "Erro ao salvar preferências", variant: "destructive" });
    },
  });

  const toggleTheme = () => {
    let newTheme: string;
    if (theme === 'dark') {
      newTheme = 'light';
    } else if (theme === 'light') {
      newTheme = 'system';
    } else {
      newTheme = 'dark';
    }
    
    setTheme(newTheme);
    savePreferencesMutation.mutate({ themePreference: newTheme });
  };

  const handleMarkAsRead = async (notificationId: number) => {
    try {
      const csrfResponse = await fetch('/api/csrf-token', { credentials: 'include' });
      const { csrfToken } = await csrfResponse.json();

      await fetch(`/api/notifications/${notificationId}/read`, {
        method: "PUT",
        credentials: "include",
        headers: {
          "Content-Type": "application/json",
          "X-CSRF-Token": csrfToken,
        },
      });

      setNotifications(prev => prev.map(n => 
        n.id === notificationId ? { ...n, read: true } : n
      ));
      setUnreadCount(prev => Math.max(0, prev - 1));
    } catch (error) {
      console.error("Failed to mark notification as read:", error);
    }
  };

  const handleMarkAllAsRead = async () => {
    try {
      const csrfResponse = await fetch('/api/csrf-token', { credentials: 'include' });
      const { csrfToken } = await csrfResponse.json();

      await fetch("/api/notifications/mark-all-read", {
        method: "PUT",
        credentials: "include",
        headers: {
          "Content-Type": "application/json",
          "X-CSRF-Token": csrfToken,
        },
      });

      setNotifications(prev => prev.map(n => ({ ...n, read: true })));
      setUnreadCount(0);
    } catch (error) {
      console.error("Failed to mark all as read:", error);
    }
  };

  const handleLogout = async () => {
    try {
      await fetch("/api/auth/logout", {
        method: "POST",
        credentials: "include",
      });

      toast({
        title: "Logout realizado",
        description: "Até logo!",
      });

      setLocation("/");
    } catch (error) {
      toast({
        variant: "destructive",
        title: "Erro ao fazer logout",
        description: "Tente novamente.",
      });
    }
  };

  if (!user) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary"></div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <div className="lg:grid lg:grid-cols-[280px_1fr]">
        <aside
          className={`fixed inset-y-0 left-0 z-50 w-72 bg-card border-r transform transition-transform duration-200 ease-in-out lg:relative lg:translate-x-0 ${
            sidebarOpen ? "translate-x-0" : "-translate-x-full"
          }`}
        >
          <div className="flex h-16 items-center justify-between px-6 border-b">
            <div className="flex items-center gap-2">
              <Sparkles className="h-6 w-6 text-primary" />
              <span className="text-xl font-bold bg-gradient-to-r from-primary to-primary/70 bg-clip-text text-transparent">
                LUCREI
              </span>
            </div>
            <Button
              variant="ghost"
              size="icon"
              className="lg:hidden"
              onClick={() => setSidebarOpen(false)}
            >
              <X className="h-5 w-5" />
            </Button>
          </div>

          <nav className="flex-1 space-y-1 px-4 py-4 overflow-y-auto">
            {navigation.map((item) => {
              const Icon = item.icon;
              const isActive = location === item.href;

              return (
                <Button
                  key={item.name}
                  variant={isActive ? "secondary" : "ghost"}
                  className="w-full justify-start gap-3 h-10"
                  onClick={() => {
                    setLocation(item.href);
                    setSidebarOpen(false);
                  }}
                >
                  <Icon className="h-4 w-4 flex-shrink-0" />
                  <span className="text-sm">{item.name}</span>
                </Button>
              );
            })}
          </nav>

          <div className="border-t">
            <div className="p-4 space-y-2">
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="ghost" className="w-full justify-start gap-3 h-10">
                    <HelpCircle className="h-4 w-4" />
                    <span className="text-sm flex-1 text-left">Ajuda</span>
                    <ChevronDown className="h-4 w-4" />
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end" className="w-56">
                  <DropdownMenuItem onClick={() => {
                    setLocation("/help/videoaulas");
                    setSidebarOpen(false);
                  }}>
                    Videoaulas para iniciantes
                  </DropdownMenuItem>
                  <DropdownMenuItem onClick={() => {
                    setLocation("/help/guias");
                    setSidebarOpen(false);
                  }}>
                    Guias de ajuda
                  </DropdownMenuItem>
                  <DropdownMenuItem onClick={() => {
                    setLocation("/help/dicas");
                    setSidebarOpen(false);
                  }}>
                    Dicas
                  </DropdownMenuItem>
                  <DropdownMenuItem onClick={() => {
                    setLocation("/help/feedback");
                    setSidebarOpen(false);
                  }}>
                    Dê seu feedback
                  </DropdownMenuItem>
                  <DropdownMenuItem onClick={() => {
                    setLocation("/help/suporte");
                    setSidebarOpen(false);
                  }}>
                    Outros canais de ajuda
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            </div>
            <div className="border-t p-4">
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="ghost" className="w-full justify-start gap-3 h-auto py-2 px-2">
                    <div className="h-9 w-9 rounded-full bg-primary/10 flex items-center justify-center flex-shrink-0">
                      <span className="text-sm font-semibold text-primary">
                        {user.name?.charAt(0).toUpperCase() || user.username?.charAt(0).toUpperCase()}
                      </span>
                    </div>
                    <div className="flex-1 min-w-0 text-left">
                      <p className="text-sm font-medium truncate">{user.name || user.username}</p>
                      <p className="text-xs text-muted-foreground truncate">{user.email}</p>
                    </div>
                    <ChevronDown className="h-4 w-4 flex-shrink-0" />
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end" className="w-56">
                  <DropdownMenuItem onClick={() => setLocation("/app/profile")}>
                    {t('nav.profile')}
                  </DropdownMenuItem>
                  <DropdownMenuItem onClick={() => setLocation("/app/settings")}>
                    {t('nav.settings')}
                  </DropdownMenuItem>
                  <DropdownMenuItem onClick={() => setLocation("/app/categories")}>
                    {t('nav.categories')}
                  </DropdownMenuItem>
                  <DropdownMenuItem onClick={() => setLocation("/app/cost-centers")}>
                    {t('nav.costCenters')}
                  </DropdownMenuItem>
                  <DropdownMenuItem onClick={() => setLocation("/app/bank-accounts")}>
                    {t('nav.bankAccounts')}
                  </DropdownMenuItem>
                  <DropdownMenuItem onClick={() => setLocation("/app/documents")}>
                    {t('nav.documents')}
                  </DropdownMenuItem>
                  <DropdownMenuItem onClick={() => setLocation("/app/tags")}>
                    {t('nav.tags')}
                  </DropdownMenuItem>
                  <DropdownMenuItem onClick={() => setLocation("/app/export")}>
                    {t('nav.export')}
                  </DropdownMenuItem>
                  <DropdownMenuSeparator />
                  <DropdownMenuItem onClick={() => setLocation("/app/subscription")}>
                    {t('nav.subscription')}
                  </DropdownMenuItem>
                  <DropdownMenuItem onClick={() => setLocation("/app/pricing")}>
                    {t('nav.pricing')}
                  </DropdownMenuItem>
                  <DropdownMenuSeparator />
                  <DropdownMenuItem onClick={handleLogout}>
                    <LogOut className="h-4 w-4 mr-2" />
                    {t('nav.logout')}
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            </div>
          </div>
        </aside>

        {sidebarOpen && (
          <div
            className="fixed inset-0 bg-black/50 z-40 lg:hidden"
            onClick={() => setSidebarOpen(false)}
          />
        )}

        <div className="flex flex-col min-h-screen">
          <div className="relative overflow-hidden bg-gradient-to-r from-primary/90 via-purple-600/90 to-primary/90 backdrop-blur-sm border-b border-primary/20 shadow-lg">
            <div className="absolute inset-0 bg-grid-white/[0.05] bg-[length:20px_20px]" />
            <div className="container mx-auto px-4 py-4 relative">
              <div className="flex items-center justify-between">
                <Button
                  variant="ghost"
                  size="icon"
                  className="lg:hidden text-white hover:bg-white/20"
                  onClick={() => setSidebarOpen(true)}
                >
                  <Menu className="h-5 w-5" />
                </Button>

                <div className="flex items-center gap-4 ml-auto">
                  <DropdownMenu>
                    <DropdownMenuTrigger asChild>
                      <Button variant="ghost" size="icon" className="relative text-white hover:bg-white/20">
                        <Bell className="h-5 w-5" />
                        {unreadCount > 0 && (
                          <span className="absolute -top-1 -right-1 h-5 w-5 rounded-full bg-red-500 text-white text-xs flex items-center justify-center">
                            {unreadCount}
                          </span>
                        )}
                      </Button>
                    </DropdownMenuTrigger>
                    <DropdownMenuContent align="end" className="w-80">
                      <div className="flex items-center justify-between p-2 border-b">
                        <span className="font-semibold">Notificações</span>
                        {unreadCount > 0 && (
                          <Button variant="ghost" size="sm" onClick={handleMarkAllAsRead}>
                            <Check className="h-4 w-4 mr-1" />
                            Marcar todas como lidas
                          </Button>
                        )}
                      </div>
                      <div className="max-h-96 overflow-y-auto">
                        {notifications.length === 0 ? (
                          <div className="p-4 text-center text-muted-foreground">
                            Nenhuma notificação
                          </div>
                        ) : (
                          notifications.map((notification) => (
                            <DropdownMenuItem
                              key={notification.id}
                              className={`p-3 cursor-pointer ${!notification.read ? 'bg-primary/5' : ''}`}
                              onClick={() => !notification.read && handleMarkAsRead(notification.id)}
                            >
                              <div className="flex flex-col gap-1">
                                <span className="font-medium">{notification.title}</span>
                                <span className="text-sm text-muted-foreground">{notification.message}</span>
                              </div>
                            </DropdownMenuItem>
                          ))
                        )}
                      </div>
                    </DropdownMenuContent>
                  </DropdownMenu>

                  <Button
                    variant="ghost"
                    size="icon"
                    onClick={() => setTheme(theme === "dark" ? "light" : "dark")}
                    className="text-white hover:bg-white/20"
                  >
                    {theme === "dark" ? <Sun className="h-5 w-5" /> : <Moon className="h-5 w-5" />}
                  </Button>

                  <Button
                    variant="ghost"
                    className="text-white hover:bg-white/20"
                    onClick={() => setLocation("/app/settings")}
                  >
                    <Settings className="h-5 w-5 mr-2" />
                    {user?.name || user?.email}
                  </Button>
                </div>
              </div>
            </div>
          </div>

          <main className="flex-1 overflow-y-auto bg-background">
            {children}
          </main>
        </div>
      </div>
      <HelpButton />
    </div>
  );
}
